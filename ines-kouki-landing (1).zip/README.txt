═══════════════════════════════════════════════════════════════
LANDING PAGE INÈS KOUKI — GUIDE D'INTÉGRATION WORDPRESS
═══════════════════════════════════════════════════════════════

Ce dossier contient :
  • index.html        → La landing page complète (HTML + CSS + JS + photo)
  • og-preview.jpg    → L'image de partage pour LinkedIn/WhatsApp/Facebook
  • README.txt        → Ce guide

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️  IMPORTANT — WordPress n'accepte pas un upload HTML brut
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Tu ne peux PAS uploader ce zip dans le menu "Apparence > Thèmes"
de WordPress — ce n'est pas un thème WordPress, c'est une page
HTML autonome. Voici les 3 méthodes pour l'intégrer.


═══════════════════════════════════════════════════════════════
MÉTHODE 1 — PLUGIN "CUSTOM HTML PAGE" (LE PLUS SIMPLE)
═══════════════════════════════════════════════════════════════

Recommandé pour démarrer rapidement. Délai d'intégration : 10 min.

1. Dans WordPress, va dans "Extensions > Ajouter"
2. Cherche : "Insert Headers and Footers" (par WPBeginner)
3. Installe et active

4. Crée une nouvelle page :
   - Pages > Ajouter
   - Titre : "Réserver un appel" (ou laisse vide)
   - Permalink : /reserver-un-appel  (modifiable dans "Réglages")

5. Bascule en mode "Code" (pas "Visuel") :
   - Dans l'éditeur Gutenberg : ajoute un bloc "HTML personnalisé"
   - Dans l'éditeur Classic : onglet "Texte" en haut à droite

6. Ouvre index.html dans Notepad (Windows) ou TextEdit (Mac)

7. Copie TOUT le contenu entre les balises <body> et </body>
   (PAS le <html>, <head>, ni les balises <body> elles-mêmes)

8. Colle dans le bloc HTML personnalisé

9. Pour les styles CSS et le JavaScript :
   - Va dans "Réglages > Insert Headers and Footers"
   - Dans la zone "Scripts dans le head", colle TOUT le contenu
     de la balise <style>...</style> de index.html
     (entoure-le de balises <style></style>)
   - Dans la zone "Scripts dans le footer", colle le contenu
     de la balise <script>...</script>
     (entoure-le de balises <script></script>)

10. Publie la page

LIMITE de cette méthode : le thème WordPress va englober ta page
(header, footer, sidebar du thème seront visibles). Pour un effet
plein écran, utilise la Méthode 2.


═══════════════════════════════════════════════════════════════
MÉTHODE 2 — TEMPLATE PAGE PERSONNALISÉ (RECOMMANDÉ)
═══════════════════════════════════════════════════════════════

Pour un rendu pleine page sans header/footer du thème.
Délai : 30 min, requiert accès FTP ou éditeur de fichiers.

1. Connecte-toi à ton hébergeur (cPanel, FTP, etc.)

2. Va dans : /wp-content/themes/[ton-thème-actif]/

3. Crée un nouveau fichier nommé : page-reserver-appel.php

4. Colle ce contenu en haut du fichier :

   <?php
   /*
    * Template Name: Réserver un appel
    */
   ?>

5. Sous ces lignes, colle TOUT le contenu de index.html
   (du <!DOCTYPE html> jusqu'au </html>)

6. Sauvegarde et upload

7. Dans WordPress :
   - Crée une nouvelle page "Réserver un appel"
   - Dans "Attributs de la page" (panneau de droite),
     sélectionne "Réserver un appel" comme Template
   - Publie

8. Visite l'URL : https://tonsite.com/reserver-un-appel
   → La page s'affiche en pleine largeur sans le thème.


═══════════════════════════════════════════════════════════════
MÉTHODE 3 — HÉBERGEMENT STATIQUE SÉPARÉ (LE PLUS PROPRE)
═══════════════════════════════════════════════════════════════

Au lieu de WordPress, héberge la page sur un sous-domaine :
  • appel.ineskouki.com  →  pointe vers le HTML
  • ineskouki.com        →  reste WordPress

Avantages :
  • Performance maximale (pas de surcharge WordPress)
  • Aucune interférence avec le thème
  • Plus simple à maintenir

Hébergeurs gratuits compatibles :
  • Netlify (drag & drop le zip → URL en 30 sec)
  • Vercel (même principe)
  • GitHub Pages (déjà utilisé pour ines-kouki-pmp)
  • Cloudflare Pages

Procédure Netlify (la plus simple) :
1. Va sur netlify.com → "Deploy manually"
2. Dezip ce dossier
3. Glisse le dossier dans la zone de drop
4. Tu obtiens une URL en .netlify.app
5. Configure le domaine personnalisé dans Réglages


═══════════════════════════════════════════════════════════════
IMAGE DE PARTAGE (og-preview.jpg)
═══════════════════════════════════════════════════════════════

Cette image apparaît quand le lien est partagé sur :
  • LinkedIn  • WhatsApp  • Facebook  • Slack  • Twitter

Méthode 1 (WordPress page) :
  - Plugin "Yoast SEO" ou "Rank Math"
  - Dans la page, section "Réseaux sociaux"
  - Upload og-preview.jpg dans "Image Facebook"
  - Le plugin gère automatiquement les balises Open Graph

Méthode 2 (template) ou Méthode 3 :
  - Upload og-preview.jpg à la racine du site
  - Les balises Open Graph dans index.html pointent déjà vers
    /og-preview.jpg : c'est automatique


═══════════════════════════════════════════════════════════════
CALENDLY & WHATSAPP — RIEN À CONFIGURER
═══════════════════════════════════════════════════════════════

Tous les liens sont déjà actifs dans le code :
  • Calendly  → calendly.com/ines-kouki-yb9r/30min
  • WhatsApp  → wa.me/33631805966
  • Email     → ines.kouki@outlook.com
  • LinkedIn  → linkedin.com/in/ines-kouki-ik

Pour les modifier ultérieurement, ouvre index.html dans un
éditeur (Notepad++, VS Code, Sublime Text) et fais
"Rechercher / Remplacer" sur l'URL concernée.


═══════════════════════════════════════════════════════════════
BESOIN D'AIDE ?
═══════════════════════════════════════════════════════════════

La méthode 1 marche dans 95% des cas. Si elle ne fonctionne pas,
le thème WordPress actuel est probablement trop intrusif —
passe alors à la méthode 2 ou 3.

Élaboré par Hafidha Najjar — Media Marketing Agency
Pour Inès Kouki — Personal Branding & Stratégie LinkedIn
Avril 2026
